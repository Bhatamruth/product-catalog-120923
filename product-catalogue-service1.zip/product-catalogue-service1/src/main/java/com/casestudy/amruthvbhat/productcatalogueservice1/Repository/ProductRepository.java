package com.casestudy.amruthvbhat.productcatalogueservice1.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.casestudy.amruthvbhat.productcatalogueservice1.Model.Product;

/**
 * This is a repository class that interacts with the database to perform CRUD operations
 * on a specific entity.
 *
 * <p>
 * You can use this repository to perform database operations related to the 'YourEntity' entity.
 * It provides methods for saving, updating, deleting, and querying 'YourEntity' objects.
 * </p>
 *
 * @author Your Name
 * @version 1.0
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
  // Define the findByCategory method to retrieve products by category
  List<Product> findByCategory(String category);

  List<Product> findByCategoryAndPriceBetween(String category, Double minPrice, Double maxPrice);
}