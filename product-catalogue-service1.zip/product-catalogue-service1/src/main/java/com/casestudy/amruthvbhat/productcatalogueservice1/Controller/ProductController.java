package com.casestudy.amruthvbhat.productcatalogueservice1.Controller;



import java.util.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.casestudy.amruthvbhat.productcatalogueservice1.Model.Product;
import com.casestudy.amruthvbhat.productcatalogueservice1.Service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * A Spring Framework annotation indicating that this class is a controller
 * that handles HTTP requests and returns HTTP responses. Controllers annotated
 * with {@code @RestController} are typically used to create RESTful APIs.
 * This annotation is a specialized version of {@code @Controller} that includes
 * the {@code @ResponseBody} annotation on all of its methods.
 */
@RestController
public class ProductController {
 
  @Autowired
  private ProductService service;
     
  // RESTful API methods for Retrieval operations

  /**
   * Retrieve a list of all products.

   * This endpoint allows clients to retrieve a list of all available products.
   *
   * @return A list of all products.
   */
  @GetMapping("/products")
  public ResponseEntity<?> list() {
    try {
      List<Product> products = service.listAll();

      if (products.isEmpty()) {
        // If the list is empty, return a custom message
        return ResponseEntity.ok("No products found.");
      }

      // If the list is not empty, return the list of products
      return ResponseEntity.ok(products);
    } catch (Exception e) {
      // Handle exceptions, e.g., if there's an error while fetching the list
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body("Error occurred while fetching the list of products.");
    }
  } //updated on 11-09-23
 
  /**
   * Retrieve a product by its unique ID.
   *
   * @param id The unique identifier of the product.
   * @return The product information if found, or an error message if not found.
   */
  @GetMapping("/products/{id}")
  public ResponseEntity<?> get(@PathVariable Integer id) {
    try {
      Product product = service.get(id);
      String successMessage = "Product Found!! " + "\n" + "\nProduct ID:" + product.getId()
          + "\nProduct name:" + product.getName() + "\nProduct price:" 
          + product.getPrice() + "\nProduct category:" + product.getCategory(); 
          
      // Return a custom success message along with the product information
      return ResponseEntity.ok(successMessage);
        }
    catch (NoSuchElementException e) {
      return ResponseEntity.status(HttpStatus.NOT_FOUND)
              .body("Product with ID " + id + " not found.");
    }
  } //updated on 11-09-23
    
  // RESTful API method for Create operation
  /**
   * Handle a POST request to create a new product.
   *
   * This method is responsible for creating a new product resource in the system
   * based on the provided request data. It processes the incoming HTTP POST request
   * to create a new product and returns a response indicating the success or failure
   * of the operation.
   *
   * @param productRequest The request body containing the details of the new product
   *                       to be created.
   * @return A ResponseEntity representing the result of the operation. If the product
   *         creation is successful, it returns HTTP status 201 (Created) along with
   *         the newly created product's details. If there is an error in the request
   *         or product creation process, it returns an appropriate error response.
   *
   * @throws BadRequestException If the incoming request data is invalid or missing
   *                            required fields.
   * @throws InternalServerErrorException If an unexpected error occurs during the
   *                                     product creation process.
   */
  @PostMapping("/products")
  public ResponseEntity<String> add(@RequestBody Product product) {
    try {
      Product savedProduct = service.save(product);         
      // Return a custom success message indicating the added product
      String successMessage = "Product has been added successfully. Added Product Details: \n" 
          + "\nProductID:" + savedProduct.getId()+ "\nProductName:"
          + savedProduct.getName() + "\nProductPrice:" + savedProduct.getPrice()
          + "\nProductCategory:"
          + savedProduct.getCategory(); // Modify this as per your Product class
      return ResponseEntity.ok(successMessage);
    } catch (Exception e) {
      // Handle exceptions, e.g., if there's an error while adding the product
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
              .body("Error occurred while adding the product.");
    }
  } //updated on 11-09-23
     
  // RESTful API method for Update operation
  /**
   * Update a product with the specified ID.
   *
   * @param id The ID of the product to update.
   * @param product The updated product data as a request payload.
   * @return The updated product.
   * @throws NotFoundException if the product with the given ID does not exist.
   */
  @PutMapping("/products/{id}")
  public ResponseEntity<String> update(@RequestBody Product product, @PathVariable Integer id) {
    try {
      Product existProduct = service.get(id);
      service.save(product);
      return ResponseEntity.ok("Product updated successfully");
    } catch (NoSuchElementException e) {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found");
    }
  } //updated on 11-09-23
  
  // RESTful API method for Delete operation
  /**
   * Deletes a product with the specified ID.

   * This endpoint allows the deletion of a product resource identified by its unique ID.
   * The product will be removed from the system permanently.
   *
   * @param id The ID of the product to delete.
   * @return A ResponseEntity with a status code indicating the result of the deletion operation.
   *         If the product is successfully deleted, it returns HttpStatus.NO_CONTENT (204).
   *         If the specified product ID is not found, it returns HttpStatus.NOT_FOUND (404).
   *         If there was an error during the deletion process,
   *          it returns HttpStatus.INTERNAL_SERVER_ERROR (500).
   *
   */
  @DeleteMapping("/products/{id}")
  public ResponseEntity<String> delete(@PathVariable Integer id) {
    try {
      Product deletedProduct = service.delete(id);
      // Return a custom success message indicating the deleted product
      String successMessage = "Product with ID " + id 
          + " has been deleted successfully. Deleted Product: " + deletedProduct.getName();
      return ResponseEntity.ok(successMessage);
    } catch (NoSuchElementException e) {
      // Handle exceptions, e.g., if the product with the given ID does not exist
      return ResponseEntity.status(HttpStatus.NOT_FOUND)
              .body("Product with ID " + id + " not found.");
    }
  } //updated on 11-09-23
  /**
   * Retrieve a list of products based on the specified category.

   * This endpoint allows clients to retrieve a list of products belonging to a
   * specific category. The category is specified as a path variable in the URL.
   *
   * @param category The category for which products are to be retrieved.
   * @return A list of products in the specified category.
   */
  @GetMapping("/products/category/{category}")
  public ResponseEntity<?> getByCategory(@PathVariable String category) {
    try {
      List<Product> products = service.getProductsByCategory(category);
      if (products.isEmpty()) {
        // If no products are found for the given category, return a custom error response
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                  .body("No products found for category: " + category);
      }

      return ResponseEntity.ok(products);
    } catch (Exception e) {
      // Handle exceptions, e.g., invalid category or other retrieval errors
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
              .body("Internal server error occurred.");
    }
  }
  
  
  /**
   * Retrieve a list of products within a specific category and price range.
   * This endpoint allows clients to retrieve a
   *  list of products that belong to a particular category
   * and fall within a specified price range.
   */
  @GetMapping("/products/category/{category}/price-range")
  public ResponseEntity<?> getProductsByCategoryAndPriceRange(
      @PathVariable String category,
      @RequestParam(name = "minPrice") Double minPrice,
      @RequestParam(name = "maxPrice") Double maxPrice) {
    try {
      List<Product> products = service
          .getProductsByCategoryAndPriceRange(category, minPrice, maxPrice);

      if (products.isEmpty()) {
        // If no products are found for the given category and price range,
        //return a custom error response
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
       .body("No products found for category: " + category + " within the specified price range.");
      }

      return ResponseEntity.ok(products);
    } catch (Exception e) {
      // Handle exceptions, e.g., invalid category or other retrieval errors
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
              .body("Internal server error occurred.");
    }
  }

}

