package com.casestudy.amruthvbhat.productcatalogueservice1.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.casestudy.amruthvbhat.productcatalogueservice1.security.JwtAuthenticationEntryPoint;
import com.casestudy.amruthvbhat.productcatalogueservice1.security.JwtAuthenticationFilter;


/**
 * This class serves as a configuration class for the Spring application.
 * It defines and configures various beans and components used in the application.
 * You can use the {@code @Configuration} annotation to declare this class as a
 * configuration source.
 *
 * @author Your Name
 * @since 1.0
 */
@Configuration
public class SecurityConfig {


  @Autowired
  private JwtAuthenticationEntryPoint point;
    
  @Autowired
  private JwtAuthenticationFilter filter;
  
  /**
   * This method defines a Spring bean that provides a specific functionality.
   * You can use this bean by injecting it into other Spring components.
   *
   * @return An instance of the bean that provides the specified functionality.
   */
  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    //configuration
    http.csrf(csrf -> csrf.disable())
        .cors(cors -> cors.disable())
        .authorizeHttpRequests(auth -> auth.requestMatchers("/products/**")
                .authenticated()
                .requestMatchers("/auth/login")
                .permitAll().anyRequest().authenticated())
        .exceptionHandling(ex -> ex.authenticationEntryPoint(point))
        .sessionManagement(session -> 
        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
    http.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class);
    return http.build();
  }


}




